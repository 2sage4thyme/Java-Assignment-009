import java.util.Scanner;

public class ArrayProcessing {
    Integer[] intArray;
    static Scanner s;
int length;

    public ArrayProcessing() {
        length = 5;
        intArray = new Integer[length];
       s = new Scanner(System.in);
       getNumbers();
       processNumbers();

    }

    public void getNumbers() {
        int i = 0;
        int thing = intArray.length;
        System.out.printf("Enter %d numbers:\n", length);
        while (i<thing) {
            intArray[i] = s.nextInt();
            i++;

        }
    }

        public void processNumbers(){

            while(true){
               int var = printMenu();
               switch(var){
                   case 1 :
                       add();

                       break;
                   case 2:

                       mult();

                       break;

                   case 3 :
                       print();

                       break;

                   case 4:
                       reverse();

                       break;

                   case 5: System.exit(0);

                   }


            }
        }
        public static int printMenu(){
            System.out.println("\n1) Add numbers \n2) Multiply numbers " +
                    "\n3) Print numbers \n4) Print numbers in reverse \n5) Quit\n");

            return s.nextInt();
        }
 public void add(){
        int i = 0;
        int sum  = 0;
        while (i<intArray.length){

            sum +=intArray[i];

            i++;
        } System.out.printf("The sum of your numbers is: %d %n", sum);

    }

    public void mult() {
        int i = 0;
        int mult = 1;
        while (i < intArray.length) {

            mult *= intArray[i];
            i++;

        }
        System.out.printf("The product of your numbers is: %d %n", mult);
    }
    public void print(){
        int i = 0;
            while(i<intArray.length){
                System.out.print(intArray[i] + " ");
                i++;

        }
            System.out.println();

    }

    public void reverse(){
        int i = intArray.length;
        while (i> 0){

            System.out.print(intArray[i-1] + " ");

            i--;
        }

    }


public static void main(String[] args){
        new ArrayProcessing();

}
}